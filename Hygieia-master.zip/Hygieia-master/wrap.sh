# https://github.com/takari/maven-wrapper
mvn -N io.takari:maven:wrapper -Dmaven=3.3.9
