## Hygieia Api

[![Build Status](https://api.travis-ci.com/Hygieia/api.svg?branch=master)](https://travis-ci.com/Hygieia/api?branch=master) [![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=Hygieia_api&metric=alert_status)](https://sonarcloud.io/dashboard?id=Hygieia_api)
[![Maven Central](https://img.shields.io/maven-central/v/com.capitalone.dashboard/api.svg?label=Maven%20Central)](https://search.maven.org/search?q=g:%22com.capitalone.dashboard%22%20AND%20a:%22api%22)
[![License](https://img.shields.io/badge/license-Apache%202-blue.svg)](https://www.apache.org/licenses/LICENSE-2.0)
[![Gitter Chat](https://badges.gitter.im/Join%20Chat.svg)](https://www.apache.org/licenses/LICENSE-2.0)
<br>
<br>
The README is in the [gh-pages](https://github.com/capitalone/Hygieia/blob/gh-pages/pages/hygieia/api/api.md) branch. Please update it there.
