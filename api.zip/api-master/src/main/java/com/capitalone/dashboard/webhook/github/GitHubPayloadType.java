package com.capitalone.dashboard.webhook.github;

public enum GitHubPayloadType {
    Push,
    PullRequest,
    Issues,
    Unknown
}

