package com.capitalone.dashboard.client;

public enum RestAuthType {
    BASIC,
    TOKEN;
}
