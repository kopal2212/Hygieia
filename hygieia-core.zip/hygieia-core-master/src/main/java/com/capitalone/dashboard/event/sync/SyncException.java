package com.capitalone.dashboard.event.sync;

public class SyncException extends Exception{
    public SyncException(String message) {
        super(message);
    }
}
