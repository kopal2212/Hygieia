package com.capitalone.dashboard.model;

public enum AuthType {

	STANDARD,
	LDAP,
	APIKEY;
	
}
