package com.capitalone.dashboard.repository;

/**
 * Marker interface for repository scanning
 */
public interface RepositoryPackage {
}
