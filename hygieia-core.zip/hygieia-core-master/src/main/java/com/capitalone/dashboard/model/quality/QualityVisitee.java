package com.capitalone.dashboard.model.quality;

public interface QualityVisitee {

    void accept(QualityVisitor visitor);
}
