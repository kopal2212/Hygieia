package com.capitalone.dashboard.model;

public class AutoDiscoverCollectorItem extends CollectorItem {

    private AutoDiscoveryStatusType autoDiscoverStatus;


    public AutoDiscoveryStatusType getAutoDiscoverStatus() {
        return autoDiscoverStatus;
    }

    public void setAutoDiscoverStatus(AutoDiscoveryStatusType autoDiscoverStatus) {
        this.autoDiscoverStatus = autoDiscoverStatus;
    }


}
