package com.capitalone.dashboard.response;

public class CloudVirtualNetworkAggregatedResponse {

}