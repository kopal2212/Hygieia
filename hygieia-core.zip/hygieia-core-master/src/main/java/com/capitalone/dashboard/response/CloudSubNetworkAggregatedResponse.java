package com.capitalone.dashboard.response;

public class CloudSubNetworkAggregatedResponse {
    
}